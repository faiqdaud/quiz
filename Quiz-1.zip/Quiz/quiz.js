
const start = document.getElementById("start");
const quiz = document.getElementById("quiz");
var q1 = localStorage.getItem("quiz");
var name = localStorage.getItem("Name");
const question = document.getElementById("question");
const qImg = document.getElementById("qImg");
const choiceA = document.getElementById("A");
const choiceB = document.getElementById("B");
const choiceC = document.getElementById("C");
const choiceD = document.getElementById("D");
const scoreDiv = document.getElementById("scoreContainer");
var ques = 0,typeq=0;
let questions = [];
var lastQuestion;
var QuesType;
    var mcq,tfq,fiq,sq;
var arr =[];
var check = false;
function MCQuestions()
{
    console.log(runningQuestion);
    let q = questions.MCQuestion[ques];
     question.innerHTML="<h3 style='text-align: center'> <b style='text-align: left'> "+'\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0'+runningQuestion+" of "+lastQuestion+'\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0'+"           Score :"+score+"<b></h3>";
    var qq = document.createElement("h3");
    var br = document.createElement("br");
    qq.innerHTML= q.q;
    document.getElementById("question").appendChild(qq);
    document.getElementById("quiz").appendChild(br);
    // alert(q.choice1);
    choiceA.innerHTML = q.choice1;
    choiceB.innerHTML = q.choice2;
    choiceC.innerHTML = q.choice3;
    choiceD.innerHTML = q.choice4;
    if(ques == mcq - 1 )
    {
        arr[typeq]=true;
  
     }
    
    
}

function TFQuestion()
{

    let q = questions.TFQuestion[ques];
     question.innerHTML="<h3 style='text-align: center'> <b style='text-align: left'> "+'\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0'+(lastQuestion - runningQuestion-1) +" of "+lastQuestion+" remaining"+'\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0'+"Score :"+score+"<b></h3>";
    var qq = document.createElement("h3");
    var br = document.createElement("br");
    qq.innerHTML= q.q;

    document.getElementById("question").appendChild(qq);
    document.getElementById("quiz").appendChild(br);
    choiceA.innerHTML = q.Tchoice;
    choiceB.innerHTML = q.Fchoice;
    choiceC.style.visibility="hidden";
    choiceD.style.visibility="hidden";
    
    if(ques == tfq - 1 )
    {

        arr[typeq]=true;
        console.log(arr);
    }
       
}
function FillInQuestion()
{
    let q = questions.FillIn[ques];
     question.innerHTML="<h3 style='text-align: center'> <b style='text-align: left'> "+'\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0'+(lastQuestion - runningQuestion-1) +" of "+lastQuestion+" remaining"+'\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0'+"Score :"+score+"<b></h3>";
    var qq = document.createElement("h3");
    var br = document.createElement("br");
    var input = document.createElement("input");
    input.type = "text";
    input.id = "fillans"
    qq.innerHTML= q.q+"  "; 
    var div = document.createElement("div");
    var button = document.createElement("button");
    button.innerHTML="Next";
    button.classList.add("button_fillin","btn", "btn-info", "btn-lg");
       button.dataset.toggle = "modal";
     button.dataset.target = "#myModal";
   
    document.getElementById("question").appendChild(qq);
    qq.appendChild(input);
     qq.appendChild(button);
    document.getElementById("quiz").appendChild(br);
    button.onclick=function click()
    {
        check = true;
        checkAnswer(input.id);
    }
    choiceA.style.visibility="hidden";
    choiceB.style.visibility="hidden";
    choiceC.style.visibility="hidden";
    choiceD.style.visibility="hidden";
    if(ques == fiq - 1 )
    {
        arr[typeq]=true;
        console.log(arr);
    }

}
function shortQuestion()
{
    let q = questions.ShortAnswer[ques];
     question.innerHTML="<h3 style='text-align: center'> <b style='text-align: left'> "+'\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0'+(lastQuestion - runningQuestion-1) +" of "+lastQuestion+" remaining"+'\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0'+"Score :"+score+"<b></h3>";
    var qq = document.createElement("h3");
    var br = document.createElement("br");
    var input = document.createElement("textarea");
    input.rows = "5";
    input.cols = "30";
    input.id="text";
    qq.innerHTML= q.q+"  ";
    var button = document.createElement("button");
    button.innerHTML="Next";
    button.classList.add("button_fillin");
    button.dataset.toggle = "modal";
     button.dataset.target = "#myModal";
    document.getElementById("question").appendChild(qq);
    qq.appendChild(button);
    document.getElementById("question").appendChild(input);
    document.getElementById("quiz").appendChild(br);
        choiceA.style.visibility="hidden";
    choiceB.style.visibility="hidden";
    choiceC.style.visibility="hidden";
    choiceD.style.visibility="hidden";
    button.onclick = function click(){
     check = true;
        checkAnswer(input.id);   
    }
    if(ques == sq - 1 )
    {
        arr[typeq]=true;
        ques=0;
        console.log(arr);
    }
}
let runningQuestion = 0;
let count = 0;
let score = 0;
function renderQuestion(){
 
 if(typeq == 0)
 {
    MCQuestions();
 }
 else if(typeq == 1)
 {
    TFQuestion();
 }
 else if(typeq == 2)
 {
    FillInQuestion();
 }
 else if(typeq == 3)
 {
    shortQuestion();   
 }

}

start.addEventListener("click",startQuiz);
function startQuiz(){
  timer(); 
    var temp;
   if(q1 == "quiz1")
   {

    $.ajax({
    async: false,
    url: "https://my-json-server.typicode.com/sconlon16/test1/Quiz1",
    type: "GET",
    dataType: "JSON",
    data: JSON.stringify({ }),
    success:function(data){
    temp = JSON.parse(JSON.stringify(data));
    }
});
   }
   else if(q1 == "quiz2")
   {
   $.ajax({
    async: false,
    url: "https://my-json-server.typicode.com/sconlon16/testDB/Quiz2",
    type: "GET",
    dataType: "JSON",
    data: JSON.stringify({ }),
    success:function(data){
    temp = JSON.parse(JSON.stringify(data));
    }
});

   }  
    // alert(temp);
    questions=temp;
    QuesType = Object.keys(questions);
    
    for(var k=0;k<QuesType.length;k++)
    {
        arr.push(false);
    }
    console.log(arr);
    mcq = questions.MCQuestion.length;
    tfq = questions.TFQuestion.length;
    fiq = questions.FillIn.length;
    sq = questions.ShortAnswer.length;
    lastQuestion = mcq+tfq+fiq+sq;
    start.style.display = "none";
    renderQuestion();
    quiz.style.display = "block";
}
function checkAnswer(answer){

    if(check == false){
        var ans = document.getElementById(answer).innerHTML;
    }else if(check == true)
    {
        var ans = document.getElementById(answer).value;
        check = false;
    }
    
    console.log(questions[QuesType[typeq]][ques].answer.correctChoice);
    if( ans == questions[QuesType[typeq]][ques].answer.correctChoice){

        answerIsCorrect();
    }else{
        answerIsWrong();
    }
    if(runningQuestion < lastQuestion-1){
       
        if(arr[typeq]==true)
        {
           // alert("here");
        ques=0;
        typeq++;
        runningQuestion++;
        renderQuestion();    
        }
        else{
            ques++;
        runningQuestion++;
        renderQuestion();
        
        }
        
    }else{
        scoreRender();
    }
    
}

function answerIsCorrect(){
    setTimeout(function () { document.getElementById("cl").click();}, 1000);
    document.getElementById("para").innerHTML="Your Answer is Correct! Good Job!";
    score = score + questions[QuesType[typeq]][ques].answer.pointsAwarded;    
 
}

function answerIsWrong(){
document.getElementById("para").innerHTML="/"+questions[QuesType[typeq]][ques].messageIfIncorrect+"/";
}

function scoreRender(){  
    document.getElementById("container").innerHTML="";
    document.getElementById("container").style.backgroundColor = "#BEBEBE";
    scoreRenderboard();

}
function scoreRenderboard(){
     var main = document.getElementById('container');
     var scorePerCent = Math.round(100 * score/20);
    if(scorePerCent>80)
    {    
    main.innerHTML += "<h1><b>"+"Congratulation! "+name+" you have passed the quiz with " +scorePerCent  +"%</b></h1><br>";}
   else
   {
   main.innerHTML += "<h1><b>"+"Sorry! "+name+" you have failed the quiz with " +scorePerCent  +"%</b></h1><br>";}

   var ele = document.createElement("p");
   ele.innerHTML="<h1><b>Time Taken:  "+hours+":"+minutes+":"+seconds+"</b></h1>";
   document.getElementById("container").appendChild(ele);   
   var div = document.createElement("div");
    var button1 = document.createElement("button");
    button1.classList.add("button_2");
    button1.innerHTML="Main Menu";
    var button2 = document.createElement("button");
    button2.classList.add("button_3");
    button2.innerHTML="Retake";
    button1.onclick = function MainMenu() {
        window.location.href="index-1.html";
    }
    button2.onclick = function reset() {
    window.location.href="index.html";
    }
    document.getElementById("append").appendChild(button1);
    document.getElementById("append").appendChild(button2);
    document.getElementById("append").appendChild(div);

}

//Timer
    var h1 = document.getElementsByTagName('h1')[0];
    seconds = 0, minutes = 0, hours = 0;

function add() {
    seconds++;
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            hours++;
        }
    }
    
    h1.textContent = (hours ? (hours > 9 ? hours : "0" + hours) : "00") + ":" + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);

    timer();
}
function timer() {
    t = setTimeout(add, 1000);
}

